import java.security.SecureRandom;
import java.util.Random;
import java.util.Scanner;



/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains the max array size and array as a int . it holds all the methods to be called on by the main driver class.
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *
 * @author/Student: Christopher Decarie-Dawson
 */
public class BinarylinearSearch {//START
	
	/** The  max of the array size. */
private final int size=30;// max array size
	
	 /** Holds The array elements. */
 	private  int [] array;// a private int array.
	
  
	/**
	 * Instantiates a new binarylinear search.
	 */
	public BinarylinearSearch(){array = new int[size];}// calling on the array for size
	
	
	/**
	 * Recursive binary search.
	 *
	 * @param Array, The int Array
	 * @param Start, the start of the array.
	 * @param Finish, the end of the array.
	 * @param key, the user requested input
	 * @return the int output for the request.
	 */
	public int recursiveBinarySearch(int Array[], int start, int finish, int key) {// used to find the recursive binary elements.
		 if (finish>=start){  
	            int middle = start + (finish - start)/2;// finds the middle point  
	            if (Array[middle] == key){  
	            return middle;  
	            } else if (array[middle]>key){
	            	remainingElements(start,middle-1);
	            	return recursiveBinarySearch(array ,start ,middle - 1,key);//returns for remaining elements
	            	
	            }
	            remainingElements(middle+1,finish);	
	            return recursiveBinarySearch(array ,middle + 1 ,finish,key);//returns for remaining elements  
		 }
		  return -1;// if element isn't in array return.
		  }	
	
		  
	
	/**
	 * Recursive linear search.
	 *
	 * @param Array, The int Array
	 * @param Start, the start of the array.
	 * @param Finish, the end of the array.
	 * @param key, the user requested input
	 * @return the int output for the request.
	 */
	public int recursiveLinearSearch(int[] array, int start ,int finish ,int key) {// used to find the recursive linear elements.
		if(finish <start) {
			return -1;
		}else if(array[start]==key) {
			return start;
		}
	     return recursiveLinearSearch(array ,start + 1,finish,key);
}

	
	/**
	 * Iterativer binary search.
	 *
	 * @param Array, The int Array
	 * @param key, the user requested input
	 * @return the int output for the request.
	 */
	public  int iterativerBinarySearch(int[] array,int key) {// used to find the iterative Binary element.
		int start =0;
		int finish = array.length -1;
		
		while(start <=finish) {
			int middle = start + (finish -start)/2;// find the middle point.
			int element = array[middle];
			
			if(element < key) {
				start = middle +1;
				remainingElements(start,finish);//returns for remaining elements
			}else if(element > key) {
				finish = middle -1;
				remainingElements(start,finish);//returns for remaining elements
			}else {
				return middle;
			}
		}
		return -1;// if element isn't in array return.
	}

	/**
	 * Generate random ints.
	 *
	 * @return the int[] is used to generate random ints ranging from 10-100.
	 */
	public int[] generateRandomInts() {// once called it will generate a random secure array in a unorded format and and ordered format.
		System.out.println("Array of randomly generated integers: ");
		
		Random random = new SecureRandom();
		  
	        for(int i=0;i<array.length; i++){
	        	array[i]=random.nextInt((100-10)+1)+10; // min 10 , max 100
	        }
	        return array;
	        
	}

/**
 * Iterative linear search.
 *
 * @param Array, The int Array
 * @param key, the user requested input
 * @return the int output for the request.
 */
public int iterativeLinearSearch(int[] array, int key){
	for(int i =0;i<array.length;i++) {
		if(array[i]==key) {
			return i;
		}
	}
   
    return -1;// if element isn't in array return.
}
	 
	/**
	 * Remaining elements.
	 *
	 * @param Start, the start of the array.
	 * @param Finish, the end of the array.
	 */
	public void remainingElements(int start,int finish) {// prints out the Remaining elements are search operations are done.
		System.out.print("Remaing elements\n");
		for(int i = start;i<finish;i++) {
			System.out.print(+array[i]+" ");
		}
	//	System.out.print();
		    
	}	
	
	/**
	 * Empty input.
	 *
	 * @param scan the user input for errors to throws
	 * @return the string calling for a input error to the user
	 * @throws IllegalAccessException the illegal access exception
	 */
	public String emptyInput(Scanner scan) throws IllegalAccessException{// input error message for enter a space into the system.
		String message = scan.nextLine();
		if (message.isEmpty()) {
			throw  new IllegalAccessException();
		}
		return message;
	}

}//END	

			
	

