import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class will be the calling class to drive the program forward.
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *
 * @author/Student: Christopher Decarie-Dawson
 */

public class Lab2BinLinSearchTest {//START

	/**
	 * The main method is the driver of the program and takes in input from the user to for menu options which call classes to run the program.
	 * While the program is active , the user can create and display an array of 30  numbers ranging from 10 to 100.
	 * the user can then search the array for a number using four methods of search , linear and binary  of iterative or recursive.
	 * both search types will also display the remaining elements of the array as well a time display in nano and milli seconds of operation time.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		BinarylinearSearch bin = new BinarylinearSearch();
		Scanner scan  = new Scanner(System.in);// input scanner object for the system to take user input.
		int choice = 0;// holds the menu option choice.
		int[] test = new int [30];
		
				
		do {// do while loop to prompts user input for  printed menu.
			
			try {
				
				displayMainMenu();// displays the main menu.
				
				choice = Integer.parseInt(bin.emptyInput(scan));// holds the choice selected and throws an error is a mismatch is given.
				
				switch(choice) {// switch cases for each option with error messages for errors in input.
				case 1:
					 test = bin.generateRandomInts();// calls to initialize and pop. two arrays unsorted and sorted.
					 System.out.print("Unsorted array: "+Arrays.toString(test)+"\n");
				     Arrays.sort(test);// sorts the array into order.
				     System.out.print("Sorted array: "+Arrays.toString(test)+"\n");
					break;
				case 2:
					System.out.println("Please enter a number to be searched: ");// asks for the element to be found in the array and it's position using recursive search.
					int target = Integer.parseInt(bin.emptyInput(scan));// checks for the empty space error
					
					// Recursive Binary Search
					System.nanoTime();//notes time in nanoseconds
					System.currentTimeMillis();// notes time in milliseconds
					
					int result = bin.recursiveBinarySearch(test,0,test.length-1,target);// calls the method for the recursive binary search.
					System.out.println("Recursive Binary Search Result\n");
					
					long endNanoTime = System.nanoTime();// closes the timer for nanoseconds.
					long endMilliTime = System.currentTimeMillis();// closes timer for milliseconds
					if(result ==-1) {
						System.out.println(target +" is not in the array.");
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime));
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime));
					}else {
						System.out.println(target +" is at index: "+ result);
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime));
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime));
					}
					// Recursive linear Search
					System.nanoTime();//notes time in nanoseconds
					System.currentTimeMillis();// notes time in milliseconds
					
					bin.recursiveLinearSearch(test,0,test.length-1,target);// calls the method for the recursive linear search.
					
					System.out.println("recursive linear Search Resullt\n");
					
					long endNanoTime1 = System.nanoTime();// closes the timer for nanoseconds.
					long endMilliTime1 = System.currentTimeMillis();// closes timer for milliseconds
					if(result != -1) {
						System.out.println(target +" is not in the array.");
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime1));
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime1));
					}else {
						System.out.println(target +" is at index: " +result);
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime1));
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime1));	
					}
					break;
				case 3:
					System.out.print("please enter a number to be searched: ");// asks for the element to be found in the array and it's position using iterative search.
					int search =Integer.parseInt(bin.emptyInput(scan));// checks for the empty space error
					
				
					//Iterative Binary Search
					System.nanoTime();//notes time in nanoseconds// closes the timer for nanoseconds.
					System.currentTimeMillis();// notes time in milliseconds
					
					
					int searched =bin.iterativerBinarySearch(test, search);// calls the method for the iterative binary search.
					
					System.out.println("Iterative Binary Search Result\n");
					long endNanoTimes = System.nanoTime();// closes the timer for nanoseconds.
					long endMilliTimes = System.currentTimeMillis();// closes timer for milliseconds
					if(searched ==-1) {
						System.out.println(searched+" is not in the array.");
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTimes));
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTimes));
					}else {
						System.out.println(searched+" is at index: "+search);
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTimes));
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTimes));
					}
					
					
					//Iterative linear Search
					System.nanoTime();//notes time in nanoseconds
					System.currentTimeMillis();// notes time in milliseconds
					
				
					int found =bin.iterativeLinearSearch(test, search);// calls the method for iterative linear search.
					System.out.println("Iterative Linear Search Result\n");
					
					long endNanoTime4 = System.nanoTime();// closes the timer for nanoseconds.
					long endMilliTime4 = System.currentTimeMillis();// closes timer for milliseconds
					if(found ==-1) {
						System.out.println(found+" is not in the array.");
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime4));
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime4));
					}else {
						System.out.println(found+" is at index: "+search);
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime4));
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime4));
					}
					break;
				case 4:
					System.out.println("Goodbye.... have a nice day");// Goodbye message for closing the program.
					break;
				default:
					System.err.println("Invalid entry...selection options 1-4... please try again!");// Error message for inproper input.
								}				
					
			}catch(InputMismatchException | NumberFormatException | IllegalAccessException e) {
					System.err.println("Invalid entry...selection options 1-4... please try again!");// mismatch catch for input errors.
					scan.nextLine();
			}
		}while(choice != 4);// loops the program menu till 4 is input.
		
		
		scan.close();// Closes Scanner input	
		
	}
	
	/**
	 * Displays main menu in the Console for user input.
	 */
	public static void  displayMainMenu() {// displays the menu format between selections.
		System.out.print("\nSelect your option in the menu:\n"+
				"1. Initialize and populate an array of 30 random integers.\n"+
				"2. Performs recursive binary and linear search.\n"+
				"3. Perform iterative binary and linear search\n"+
				"4. To Exit\n");
		System.out.print("> ");
	}
	
	}//END


