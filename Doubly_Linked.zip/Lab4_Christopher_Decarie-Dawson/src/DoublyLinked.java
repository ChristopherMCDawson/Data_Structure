/**
 * Processing data using Doubly Linked List CST8130 Data Structures, Computer
 * Engineering Technology-Computer Science: Level 3
 * 
 * Professor: James Mwangi PhD
 * 
 * 
 * Student Name:Christopher  Decarie Dawson Student ID:040718315
 * 
 */

// ===================== class starts here=============================
class Node {
	public static final Node list = null;
	public static int mData; // data item
	public Node next; // next node in list
	public Node previous; // previous node in list
	// -------------------------------------------------------------

	public Node(int d) // constructor
	{
		mData = d;
	}

	// -------------------------------------------------------------
	// display this node data
	public void displayNode() {
		System.out.print(mData + " ");
	}
	// -------------------------------------------------------------
} // end class Node

// ===================== class design starts here =============================
class DoublyLinkedList {
	private Node first;
	private Node last;

	// -------------------------------------------------------------
	public DoublyLinkedList() {
		first = null;
		last = null;
	}

	// -------------------------------------------------------------
	public boolean isEmpty() {
		return first == null;
	}

	// -------------------------------------------------------------
	public void insertFirst(int num) {
		Node newNode = new Node(num);

		if (isEmpty())
			last = newNode;
		else
			first.previous = newNode;
		newNode.next = first;
		first = newNode;
	}

	// -------------------------------------------------------------
	public void insertLast(int num) {
		Node newNode = new Node(num);
		if (isEmpty())
			first = newNode;
		else {
			last.next = newNode;
			newNode.previous = last;
		}
		last = newNode;
	}

	// insert newNumber just after numToFind
	public boolean insertAfter(int numToFind, int newNumber) { // (assumes non-empty list)
		Node current = first;
		
		while (current.mData != numToFind) {
			current = current.next;
			if (current == null)
				return false;
		}
		Node newNode = new Node(newNumber);

		if (current == last) {
			newNode.next = null;
			last = newNode;
		} else {
			newNode.next = current.next;

			current.next.previous = newNode;
		}
		newNode.previous = current;
		current.next = newNode;
		return true;
	}

	// ------------------------------------------------// delete first node

	public Node deleteFirstNode(Node del) {

		 // Base case
        if (first == null || del == null) {
            return null;
        }
 
        // If node to be deleted is head node
        if (first == del) {
            first = del.next;
        } 
        
        // Finally, free the memory occupied by del
        return del;

	}

	// -----------------------------------------------// delete last node

	public Node deleteLastNode(Node del) {

		 // Base case
        if (last == null || del == null) {
            return null;
        }
 
        // If node to be deleted is tail node
        if (last == del) {
        	last = del.next;
        } 
        
        // Finally, free the memory occupied by del
        return del;

	}

	// -------------------------------------------------------------

	// -----------------------------------------finds, deletes and returns the node
	// that contains the given int value
	public Node searchAndDelete(Node del) {

		 // Base case
        if (first == null || del == null) {
            return null;
        }
 
        // If node to be deleted is head node
        if (first == del) {
            first = del.next;
        }
 
        // Change next only if node to be deleted
        // is NOT the last node
        if (del.next != null) {
            del.next.previous = del.previous;
        }
 
        // Change prev only if node to be deleted
        // is NOT the first node
        if (del.previous != null) {
            del.previous.next = del.next;
        }
 
        // Finally, free the memory occupied by del
        return del;

	}

	// -------------------------------------------display data from first node to
	// last node
	public void printForwards(Node node) {

		   Node last = null;
		   
	        while (node != null) {
	            System.out.print(node.mData + " ");
	            last = node;
	            node = node.next;
	        }
	 
	        System.out.println();

	}

	// -------------------------------------------display data from last node to
	// first node
	public void printBackwards(Node node) {

		   Node first = null;
		   
	        while (node != null) {
	            System.out.print(node.mData + " ");
	            first = node;
	            node = node.next;
	        }
	 
	        System.out.println();

	}
	// -------------------------------------------------------------
} // end class DoublyLinkedList

// ==========================================================
