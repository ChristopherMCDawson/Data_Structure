import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * Processing data using Doubly Linked List CST8130 Data Structures,
 * Computer Engineering Technology-Computer Science: Level 3
 * 
 * Professor: James Mwangi PhD
 * 
 * 
 *          Student Name:Christopher Decarie-Dawson 
 * 			Student ID:040718315
 * 
 */

class TestDLLApp {
	
	/**
	 * The main method.
	 *
	 * @param <E>  the element type
	 * @param args the arguments
	 * @throws IllegalAccessException the illegal access exception
	 */
	public static <E> void main(String[] args) throws IllegalAccessException {

		
				
				
				Scanner input = new Scanner(System.in);//Scanner object to scan inputs
				DoublyLinkedList nLL = new DoublyLinkedList();
		        int choice = 0;//declare choice for switch
		        
		            
						
				do {
					try {// open catch
						
						switch(choice = displayMenu(input)) {// switch statments to take in user input to the menu options which are also displayed.
						
						case 1:
							nLL.insertFirst((Integer) 0);
							System.out.println("Enter an integer to the first node: ");
							input.nextInt();
							break;
						case 2:
							nLL.insertLast((Integer)0);
							System.out.println("Enter an integer to the last node: ");
							input.nextInt();
							break;
						case 3:
							nLL.deleteFirstNode(Node.list);						
							break;
						case 4:
							nLL.deleteLastNode(Node.list);
							break;
						case 5:
							nLL.searchAndDelete( Node.list);
							System.out.println("Enter an integer to be deleted: ");
							input.nextInt(Node.mData);
							break;
						case 6:
							nLL.printForwards(Node.list);
							break;
						case 7:
							nLL.printBackwards(Node.list);
							break;
						case 8:
							System.out.println("Goodbye.... have a nice day");// Goodbye message for closing the program.
							break;
							
							default:
								System.err.println("Invalid entry...selection options 1-8... please try again!");// Error message for inproper input.
											}				
										
						
					}catch(InputMismatchException | NumberFormatException e) {
						System.err.println("Invalid entry...selection options 1-8... please try again!");// mismatch catch for input errors.
						input.nextLine();
				}
					
				}while(choice != 8);// loops the program menu till 5 is input.
				input.close();// Closes Scanner input
			}	
			
				
				/**
				 * Display menu.
				 *
				 * @param input from the user to move along the menu.
				 * @return takes in int
				 * @throws IllegalAccessException the illegal access exception
				 */
				protected static int displayMenu(Scanner input)throws IllegalAccessException {// prints the menu at program start and checks for errors entered by the user into the menu system.
					int option;
					System.out.print("\nPlease select one of the following:\n"+
							"1. Add a node to front\n"+
							"2. Add a node to back\n"+
							"3. Delete first node\n"+
							"4. Delete last node\n"+
							"5: Search and delete node\n" +
			                "6: Display forward\n" +
			                "7: Display Backward\n" +					
							"8. To Exit\n"+					
							"<must be a number between 1 - 8>\n");
					System.out.print(">  ");
					String truth = input.nextLine();
					if(truth.isBlank()){
						throw new NumberFormatException();
					}else if (truth.isEmpty()) {
						throw new IllegalArgumentException();
					}else {
						option = Integer.parseInt(truth);
					}
				return option;
			
			

	} // end of main() method
} // end class TestDLLApp
