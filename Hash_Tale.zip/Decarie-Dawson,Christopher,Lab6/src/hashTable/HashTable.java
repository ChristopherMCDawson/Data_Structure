/*
 * CET - CS Academic Level 3
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * Course: CST8130 - Data Structures
 * Lab 6
 * Professor: George Kriger 
 * Student: Christopher Decarie-Dawson
 * Student num:040718315
 * Section #: 301
 * due date: 11/28/2021
 * 
 * @author Algonquin College
 * @author George Kriger
 * @author Christopher Decarie-Dawson
 * @version 2
 */
package hashTable;

import java.util.ArrayList;
import java.util.LinkedList;




/**
 * The Class HashTable.
 *
 * @param <T> the generic type HashTable
 */
public class HashTable <T> {//Start
    /** The hash table. */
    final private ArrayList<LinkedList<T>> hashTable;
     /** The capacity. */
    int capacity;
    /**
     * Instantiates a new hash table.
     */
    public HashTable(){
        capacity = 25;
        hashTable = new ArrayList<>(capacity);
        for (int i= 0; i < capacity; i++) {
            hashTable.add(new LinkedList<T>());
        }
    }
    /**
     * Hash.
     *
     * @param key the .hashcode
     * @return the int key.
     */
    private int hash(T key) {
        int h = key.hashCode();
        h = h % capacity;
        if (h < 0) {
            h = -h;
        }
        return h;
    }
    /**
     * Adds am index to the hash temp
     *
     * @param temp location for holding Add
     * @return true, if successful
     */
    public boolean add (T temp) {
        int index = hash(temp);
        hashTable.get(index).add(temp);
        return true;
    }
    /**
     * Search.
     *
     * @param temp location for holding the Search.
     * @return true, if successful
     */
    public boolean search (T temp){
        @SuppressWarnings("unused")
		boolean b = false;
        for (int i = 0; i<hashTable.size(); i++) {
            if (hashTable.get(i).isEmpty()){
                continue;
            } else {
                int index=hash(temp);
                if (hashTable.get(index).contains(temp)) {
                    return true;
                } else {
                    index++;
                }
            }
        }
        return false;
    }
}//END

