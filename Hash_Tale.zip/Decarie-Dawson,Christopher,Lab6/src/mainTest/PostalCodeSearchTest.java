/*
 * CET - CS Academic Level 3
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * Course: CST8130 - Data Structures
 * Lab 6
 * Professor: George Kriger 
 * Student: Christopher Decarie-Dawson
 * Student num:040718315
 * Section #: 301
 * due date: 11/28/2021
 * 
 * @author Algonquin College
 * @author George Kriger
 * @author Christopher Decarie-Dawson
 * @version 2
 */

package mainTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import hashTable.HashTable;


public class PostalCodeSearchTest {//Start

    /**
     * main() which opens and read CSV file of Canadian postal codes.
     *
     * @param args command line arguments (not used)
     * @param HashTable generates a new hashTable
     * @param Gets the file using paths.get
     */
    public static void main(String[] args) {
        HashTable<String> hash = new HashTable<String>();
        String filename = "ottawa_postal_codes_prefix_only.csv";
        Path file = Paths.get(filename);
        try (BufferedReader input = Files.newBufferedReader(file)) {/// try to read the file in location.
            String line;
            while ((line = input.readLine()) != null) {
                hash.add(line);
            }//while
        }
        catch (IOException e) {// Error if no file is found
            System.err.println("Error opening file");
            e.printStackTrace();
        }
        // no need to close input. Used try-with-resources above

        System.out.println("\nGenerating random prefixes");

        for(int i = 0; i < 10; i++) {// used to print out the results.
            String key = getRandomPrefix();
            System.out.printf("Retrieving: %s ", key) ;
            if (hash.search(key)) {
                System.out.println("found");
            }else{
                System.out.println("NOT found");
            }
        }
    }
    final static SecureRandom rand = new SecureRandom();
    final static String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    final static String number = "0123456789";

    /**
     * randomly generate a prefix using the correct format for Canadian postal codes
     *
     * @return randomly generated prefix of the postal code
     */
    public static String getRandomPrefix() {
        int randomLetter = rand.nextInt(alpha.length());
        int randNumber = rand.nextInt(number.length());

        return "K" + number.charAt(randNumber) + alpha.charAt(randomLetter);
    }// getRandomPrefix()

}// class END


