import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains the main driver for the program along with the main menu and the method calls to other classes for user input and output.
 * 
 * 
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *Assignment 1
 *Due 10/3/2021
 *Done 10/3/2021
 * @author/Student: Christopher Decarie-Dawson
 * @version 1.0
 */

public class Assign1 {//START

	public static void main(String[] args) throws IllegalAccessException, NumberFormatException {
		
		Scanner input = new Scanner(System.in);// scanner input to the system.
		int option = 0;	// holds user input option.	
		Inventory inventory = new Inventory();// creates an instance of the Inventory to be called on and used during the run time.		
		do {
			try {// open catch
				
				switch(option = displayMenu(input)) {// switch statments to take in user input to the menu options which are also displayed.
				
				case 1:
					inventory.addItem(input);// add a items call to the system.
					break;
				case 2:
					System.out.println(inventory);// prints out the inventory for user reference.
					break;
				case 3:
					if(!inventory.updateQuantity(input, false))// checks to see if an item can be bought  and then updates afterward tranaction.
						System.out.println("No items to buy");
					break;
				case 4:
					if(!inventory.updateQuantity(input, true))// checks the system to see if the item can be sold and updates afterward.
					System.out.println("No items to sell");
					break;
				case 5:
					System.out.println("Goodbye.... have a nice day");// Goodbye message for closing the program.
					break;
					
					default:
						System.err.println("Invalid entry...selection options 1-5... please try again!");// Error message for inproper input.
									}				
								
				
			}catch(InputMismatchException | NumberFormatException e) {
				System.err.println("Invalid entry...selection options 1-5... please try again!");// mismatch catch for input errors.
				input.nextLine();
		}
			
		}while(option != 5);// loops the program menu till 5 is input.
		
		
	}
		
		protected static int displayMenu(Scanner input)throws IllegalAccessException {// prints the menu at program start and checks for errors entered by the user into the menu system.
			int option;
			System.out.print("\nPlease select one of the following:\n"+
					"1. Add Item to Inventory\n"+
					"2. Display Current Inventory\n"+
					"3. Buy Item(s)\n"+
					"4. Sell Item(s)\n"+
					"5. To Exit\n"+
					"<must be a number between 1 - 5>\n");
			System.out.print(">  ");
			String truth = input.nextLine();
			if(truth.isBlank()){
				throw new NumberFormatException();
			}else if (truth.isEmpty()) {
				throw new IllegalArgumentException();
			}else {
				option = Integer.parseInt(truth);
			}
		return option;
	}
	
}//END
