import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains the methods and values to update items , additems , inputcodes and if they are equal, as well as holding the
 * input place holders.
 * 
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *Assignment 1
 *Due 10/3/2021
 *Done 10/3/2021
 * @author/Student: Christopher Decarie-Dawson
 * @version 1.0
 */

 public class FoodItem {//Start
	
	 protected int itemCode;// food item code.
	 protected String itemName;// name of said food item.
	 protected float itemPrice;// price for customers from the stall.
	 protected int itemQuantityInStock;// amount of said food item in stock.
	 protected float itemCost;// price stall paid for food items per unit.

	 
	//no argument - constructor	 
public FoodItem() {
	itemCode = 0;
	itemName ="";
	itemPrice = 0.0f;
	itemQuantityInStock = 0;
	itemCost = 0.0f;

}
	
	
	
	
	
	
 @Override	
 public String toString(){// main print out for items in system.
	 return "\nItem: " + itemCode + "Name: " + itemName + "Quantity: " + itemQuantityInStock + 
			 "Price: $" + String.format("%.2f",itemPrice) +
			 "Cost: " + String.format("%.2f", itemCost);		
	}
	
	
	protected boolean updateItem(int amount){// item updater for the system when a items is  bought will uppdate the stock levels.
		
		if((itemQuantityInStock + amount)<= 0) {
			System.out.println("Quantity can't be 0");
			return false;
		}else {
			itemQuantityInStock += amount;
			return true;
		}
		
	}
	public boolean addItem(Scanner scanner) {// uses scanner to add a new item to the system.
		if(inputCode(scanner)) {// loops the additem till done is triggered to true.
			boolean done = false;

			System.out.print("Enter the name of the item: ");// request to the user for name of the item.
			itemName = scanner.nextLine();
			scanner.nextLine();
			do{// error check for correct varible input.
				try{
					System.out.print("Enter the quantity of the item: ");
					itemQuantityInStock = scanner.nextInt();
					if (itemQuantityInStock <= 0) {
						System.out.println("Invalid quantity!");
					}else
						done = true;
				}catch (InputMismatchException e) {
					System.out.println("Invalid entry!");
					scanner.nextLine();
				}
			}while (!done);// close of the lopp when the correct input has been entered.

			done = false;

			do{// error check loop for correct input from user .
				try{
					System.out.print("Enter the cost of the item: ");
					itemCost = scanner.nextFloat();
					if (itemCost <= 0) {
						System.out.println("Invalid cost");
					}else
						done = true;
				}catch (InputMismatchException e) {
					System.out.println("Invalid entry");
					scanner.nextLine();
				}
			}while (!done);// closes loop when correct unit is entered into the system.

			done = false;

			do{// error loop while request input of sales price from user.
				try{
					System.out.print("Enter the sales price of the item: ");
					itemPrice = scanner.nextFloat();
					scanner.nextLine();
					if (itemPrice <= 0) {
						System.out.println("Invalid price");
					}else
						done = true;
				}catch (InputMismatchException e) {
					System.out.println("Invalid entry");
					scanner.nextLine();
				}
			}while (!done);// closes the loop when a correct entry format has been entered.
		}return true;
	}
	
	
	public boolean isEqual(FoodItem item) {// Checks to see if the Item code is already in use and loops till a new code has been entered.

		if(item.itemCode == this.itemCode) {
			return true;
		}else {
			System.out.println("Item already exists!");
			return false;
		}
	}
	/**
	 * This method reads a valid itemCode from the Scanner object and returns true/false if successful
	 * @param scanner it is a scanner object.
	 * @return true if the code was inputed successfully otherwise returns false.
	 */
	
	
	public boolean inputCode(Scanner scanner) {// used to check for item codes in the system and adding new codes to the system.
		boolean done = false;
		do{
			try{
				System.out.print("Enter the code of the item: ");
				itemCode = scanner.nextInt();
				scanner.nextLine();
				if(!isEqual(this)) {
					System.out.println("Item does not exist in inventory!" +
							"\nItem code has been added!");
				}done = true;
			}catch (InputMismatchException e) {
				System.out.println("Invalid entry");
				scanner.nextLine();
			}
		}while (!done);// closes loop when correct entry type has been entered by the user.
		return true;
	}


}//END
