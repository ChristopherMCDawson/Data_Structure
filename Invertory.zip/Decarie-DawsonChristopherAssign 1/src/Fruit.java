import java.util.Scanner;

/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains a extendtion of the FoodItem class which adds fruits to the items , overriding the toString to add orchard
 * supplier and to override the addItem to request the name of the supplier.
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *Assignment 1
 *Due 10/3/2021
 *Done 10/3/2021
 * @author/Student: Christopher Decarie-Dawson
 * @version 1.0
 */

public class Fruit extends FoodItem {//START, Extends the FoodItem class to add fruit to the item list.
	
	
	/** The orchad name private String to hold the name of the orchad. */
private String orchadName;
	
	@Override
	
	public String toString() {// overides the toString and adds orchard supplier to it's output.
		return super.toString() + " Orchard supplier " + orchadName;
			}
	
	
	@Override	
	public boolean addItem(Scanner scanner) {// Overrides the addItem method to request a orchard supplier from the user.
		if(super.addItem(scanner)) {
			System.out.print("Enter the name of the orchard supplier: ");
			orchadName = scanner.nextLine();
			return true;			
		}
		return false;
	}

}//END
