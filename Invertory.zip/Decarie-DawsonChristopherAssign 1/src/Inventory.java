import java.util.Scanner;

// TODO: Auto-generated Javadoc
/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains the inventory array which will hold a max of 20 items and the loops to add items , updates , toSting
 * and already exists.
 * 
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *Assignment 1
 *Due 10/3/2021
 *Done 10/3/2021
 * @author/Student: Christopher Decarie-Dawson
 * @version 1.0
 */

public class Inventory {// Start
	
	/** The inventory. */
private FoodItem[] inventory;// An array for holding FoodItems.
	
	/** The num items. */
	private int numItems;// holds number of unit types in the array.

	public Inventory(){
		numItems = 0;
		inventory = new FoodItem[20];
	}

	public boolean addItem(Scanner scanner) {// menu and loop for adding  the different types of food stuffs.
		FoodItem ft = null;
		while(true){
			System.out.print("What would you like to add?\n" +
					"(F)ruit\n(V)egetable\n(P)reserve?\n\n" +
					"Choose your option: ");
			String option = scanner.nextLine().toLowerCase();// takes in both upper and lower case entrys into the system for ease.

			
			
			switch (option) {
				case "f":
					ft = new Fruit();
					ft.addItem(scanner);
					break;
				case "v":
					ft = new Vegetable();
					ft.addItem(scanner);
					break;
				case "p":
					ft = new Preserve();
					ft.addItem(scanner);
					break;
				default:
					System.out.println("Invalid entry!");// error statment if incorrect entry is added.
			}
			if (ft != null) {// closes the loop
				break;
			}
		}
		inventory[numItems] = ft;// adds it the array.
		numItems++;
		
		return true;// loops the system.
		
	}

	@Override
	public String toString() {// overrides the item printout and adds whats in the inventory to the user output.
		String display= "Inventory:\n";
			for(int i = 0; i < numItems; i++) {
				display += inventory[i].toString();
			}return display;
	}
	
	public int alreadyExists(FoodItem item) {// checks if the item already exists in the system and stops muiltples of the same item type being entered.
		for (int i = 0; i < numItems; i++) {
			if (item.itemCode == inventory[i].itemCode) {
				return i;
			}
		}return -1;
	}
	
	
	public boolean updateQuantity(Scanner scanner, boolean buyOrSell) {// updates the amounts in the array of each item ,removing amounts sold
		// and flagging an error is there aren't enough of the item to fill the order.
		if(numItems == 0){
			return false;
		}
		FoodItem item = new FoodItem();
		item.inputCode(scanner);
		int itemIndex = alreadyExists(item);
		

		if (itemIndex == -1) {
			System.out.println("Not found!");
			return false;
		} else {
			try {
				System.out.print("Enter quantity: ");
				int quantity = scanner.nextInt();
				scanner.nextLine();

				if (quantity <= 0) {
					System.out.println("Invalid quantity");
					return false;
				}else {
					System.out.println("Transaction complete!");
				}if (!buyOrSell) {
					quantity = -1 * quantity;
				}
				boolean balance = inventory[itemIndex].updateItem(quantity);

				if (!balance) {
					System.out.println("Insufficient quantity!!");
				}return balance;
			}catch (NumberFormatException e) {
				System.out.println("Invalid quantity");
				return false;
			}
		}
	}
}//END
