import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains a estendtion of Fooditem known as Preserves which overrides the request and output of addItem and toString
 * to add in jarsize.
 * 
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *Assignment 1
 *Due 10/3/2021
 *Done 10/3/2021
 *
 * @author/Student: Christopher Decarie-Dawson
 * @version 1.0
 */

public class Preserve extends FoodItem {// Start , extends the FoodItem class.

	/** The jar size  as a Integer value. */
private int jarSize;//

	public Preserve() {// default consturctor.
		jarSize = 0;// sets and empty size
	}
	
	@Override
	public String toString() {// overrides the toString to add jar size to fooditems that are preserves.
		return super.toString() + " Size : " + jarSize + "ml";
	}

	@Override
	public boolean addItem(Scanner scanner) {// overrides the additem request to add in jar size in millilitres,
		if(super.addItem(scanner)) {
			boolean done = false;
		do {// trys to catch errors.
			try {
					System.out.print("Enter the size of the jar in millilitres: ");
					jarSize = scanner.nextInt();
					done = true;
		}catch (InputMismatchException e) {
					System.out.println("Invalid entry!");
					scanner.nextLine();
		}
	} while (!done);// loop till correct entry is input.
		return true;
	}
	return false;// otherwise loop till user inputs.
	}
}//END
