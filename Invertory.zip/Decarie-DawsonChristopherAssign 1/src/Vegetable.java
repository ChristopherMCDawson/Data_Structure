import java.util.Scanner;

/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains a extendtion of the FoodItem class which adds vegetables to the input request to user and overrides the
 * toString output.
 * 
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *Assignment 1
 *Due 10/3/2021
 *Done 10/3/2021
 * @author/Student: Christopher Decarie-Dawson
 * @version 1.0
 */

public class Vegetable extends FoodItem {//Start ,extends the FoodItem class to add suppling farm names.

	private String farmName;

	public Vegetable() {// default constructor for  farm supplier.
		farmName = "";
	}
	
	@Override
	public String toString() {	// overrides the toString to add in farm supplier to printout.
		return super.toString() + " Farm Supplier:  " + farmName;
	}
	
	/**
	 * Overrides the addItem to add in a request to add farm supplier name.
	 *
	 * @param scanner that takes in user input to set it as the farmName.
	 * @return true, if successful at entering requested information.
	 */
	@Override
	public boolean addItem(Scanner scanner) {// Overrides to add in a request to user for supplying farm's name/
		if(super.addItem(scanner)) {
			System.out.print("Enter the name of the farm supplier: ");
			farmName=scanner.nextLine();
			return true;
		}return false;
	}
}//END
