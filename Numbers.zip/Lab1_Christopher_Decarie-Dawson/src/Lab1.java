
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains the dynamically allocated array and it's processing
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *
 * @author/Professor: James Mwangi PhD.
 */
public class Lab1 {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
	Scanner input  = new Scanner(System.in);// input scanner object for the system to take user input.
		

		int choice = 0;// holds the menu option choice.
		
		
		
		Numbers c1 = new Numbers();//creating a instance of the numbers array.
		
		do {// do while loop to prompts user input for  printed menu.
			try {
				displayMainMenu();
				
				choice = input.nextInt();
				
				switch(choice) {// switch cases for each option with error messages for errors in input.
				case 1:
					c1= new Numbers();// calls on the default constructor to build a default array.
					break;
				case 2:
					int size;
					System.out.println("Please enter max size of the array");// reads the max size of array method and sets the size to that entered value.
					size=input.nextInt();
					input.nextLine();
					c1= new Numbers(size);
					break;
				case 3:
					c1.addValue(input);// prompts user to add a value to the array. 
					break;
				case 4:
					c1.Print();// displays the values in the array.
					break;
				case 5:
					c1.calcAverage();// calls to display the average.
					c1.findMinMax();// calls to display the min and max of the array.
					break;					
				case 6:
					System.out.println("Goodbye.... have a nice day");// Goodbye message for closing the program.
					break;
				default:
					System.err.println("Invalid entry...selection options 1-6... please try again!");// Error message for inproper input.
								}				
				
			}catch(InputMismatchException e) {
					System.err.println("Invalid entry...selection options 1-6... please try again!");// mismatch catch for input errors.
					input.nextLine();
			}
		}while(choice != 6);// loops the program menu till 6 is input.
				
		input.close();// Closes Scanner input
		
	}
	
	/**
	 * Displays main menu in the Console for user input.
	 */
	public static void  displayMainMenu() {// displayes the menu format between selections.
		System.out.print("\nPlease select one of the following:\n"+
				"1. Initialize a default array.\n"+
				"2. To specify the max size of the array.\n"+
				"3. Add value to the array\n"+
				"4. Display values in the array.\n"+
				"5. Display average of the values,minimum valuse,maximum value.\n"+
				"6. To Exit\n");
		System.out.print("> ");
	}
	}//END


