import java.util.Arrays;
import java.util.Scanner;

/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * This class contains the dynamically allocated array and it's processing
 * Student Name:Christopher Decarie-Dawson 
 * Student Number:040718315
 * Section #: 301 
 * Course: CST8130 - Data Structures
 * CET-CS-Level 3.
 *
 * @author/Professor James Mwangi PhD.
 */
public class Numbers {//START
	/**
	 * Stores Float values.
	 */
	private Float [] numbers;//Float array named numbers
	
	/**
	 * Store the number of items currently in the array.
	 */
	private int numItems;// Stores the array items
	
	/** The stores the array size. */
	private int size;

	/**
	 * Default Constructor.
	 */
	public Numbers() {// Default Constructor
		size=4;
		numbers = new Float[size];		
		numItems=0;			
	}
	/**
	 * Constructor that initializes the numbers array.
	 * @param size - Max size of the numbers array.
	 */
	public Numbers(int size) {// Constructor that allows sizing of array.
		this.size = size;
		numbers= new Float[size];
		numItems=0;	
	}
	
	/**
	 * Adds a value in the array.
	 *
	 * @param keyboard - Scanner object to use for input
	 */
	public void addValue(Scanner keyboard) {// scans from user input to add values into the array.
		float val;
		System.out.println("Enter value:");// user prompted.
		val= keyboard.nextFloat();
		keyboard.nextLine();
		if(numItems==size) {
			System.out.println("there is no room in the array.");// error message if max array size has been reached.
		}else {
			numbers[numItems]=val;
			numItems++;
		}
	}
	
	/**
	 * Calculates the average of all the values in the numbers array.
	 *
	 * @return float value that represents the average
	 */
	public float calcAverage() {//method to find the average of the array
	
	float total=0;
	float average = 0;
	
	for(int i=0; i<numItems; i++){
    	total = total + numbers[i];
    }if(total==0) {
		average=0;
	}else {
		average=total/numItems;
	}
    
    /* This is used for displaying the formatted output
     * after decimal point.
     */
    System.out.print("The average is: "+toString(average)+", ");// output for user


		return average;
	}
	
	/**
	 * Find min and max numbers of the array.
	 *
	 * @return as float values.
	 */
	public float findMinMax() {
		float min;
		
        if(size == 0) {
            min = 0;
        }else {
      for(int i = 0; i < numItems; i++) {
      }
            }        
		float max;
				
        if(size == 0) {
            max = 0;
        }else {
      for(int i = 0; i < numItems; i++) {
      }
            }
		
		if(numItems==0) {
			min=0;
			max=0;
		}else {
			Arrays.sort(numbers);			
			min=numbers[0];
			max=numbers[numbers.length-1];
		}
	
	System.out.println("Mininum value is "+toString(min)+ " Maxium value is "+toString(max));//output for user
		return max + min;
		
	}

/**
 * To string method for the numbers array.
 *
 * @param numbers the numbers
 * @return the string
 */
//	@Override
	public String toString(float numbers) {
		
		return String.format("%.2f", numbers);
				
	}
	
	/**
	 * Prints the output of the array or declares no items to display error message.
	 */
	public void Print() {
		if(numItems==0) {
			System.out.println("there are no items to display.");
		}else {
			System.out.println("Numbers are: ");
			for(int i=0;i<numItems;i++){
				System.out.println(toString(numbers[i]));
				
			}
				
			
		}
			
		
	}

    
    }//END
		
	

