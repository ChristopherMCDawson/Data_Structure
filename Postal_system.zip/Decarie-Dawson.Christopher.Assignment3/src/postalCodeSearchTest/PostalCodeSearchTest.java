package postalCodeSearchTest;


import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import postalCodeEntry.PostalCodeEntry;
/*
 * CET - CS Academic Level 3
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * Course: CST8130 - Data Structures
 * Assignment 3
 * Professor: George Kriger 
 * Student: Christopher Decarie-Dawson
 * Student num:040718315
 * Section #: 301
 * due date: 11/21/2021
 * 
 * @author Algonquin College
 * @author George Kriger
 * @author Christopher Decarie-Dawson
 * @version 2
 */


public class PostalCodeSearchTest {//Start

	/**
	 * main() which opens and read CSV file of Canadian postal codes.
	 *
	 * @param args command line arguments (not used)
	 * 
	 */
	public static void main(String[] args) {
		
		PostalCodeEntry postalCode;
		
		HashMap <String,PostalCodeEntry> postalCodeList =new HashMap<>();// creates a HashMap using PostalCodeEntry
		
		String filename = "ottawa_postal_codes.csv";// sets the filename.
		
		Path file = Paths.get(filename);// Imports the file in the Project file using it's path.
		
		try (BufferedReader input = Files.newBufferedReader(file)) {// Try to read the input from the file
			
            String line = null;
            String delimeter = ",";// delimeter for the reader.
            
            while ((line = input.readLine()) != null) {
                String [] entry = line.split(delimeter);// calls for split on  the " ," delimeter. 
                postalCode = new PostalCodeEntry(entry);
                postalCodeList.put(postalCode.getPrefix(),postalCode);// pulls the prefix to read the file prefix and add them to the HashMap. 
            }//while
        } catch (IOException ioException) {// catch if there is no file.
            System.err.println("Error opening file");
            ioException.printStackTrace();
        } 
        for(int i = 0; i < 10; i++) {// counts out 10  random  postal info from the file using Prefix as the key.
            String Prefix;
            Prefix =PostalCodeEntry.getRandomPrefix();
            System.out.printf("\nRetrieving: %s",Prefix);
            if(postalCodeList.containsKey(Prefix)) { 
                System.out.printf("\n\t%s",postalCodeList.get(Prefix));
            }else { 
                System.out.printf("\n\tNOT FOUND");// Throws if the prefix isn't found.
            }
        }
        // no need to close input. Used try-with-resources above
    }// main()

}// class END
