
/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class contains the sorting algorithm methods called unpon by the main class driver , which while called will sort array elements by different methods depends on the selecetion.
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *
 * @version 1.0
 * @author/Student: Christopher Decarie-Dawson
 */

public class SortingAlgorithm {//START

    /**
     * Bubble sort method for sorting by the bubble sort algorithm.
     *
     * @param array : calls on the array elements in the driver class and sorts them using the Bubble algorithm style.
     */
    protected static void bubbleSort(int[] array) {// Bubble sorting method.

        for(int i = 0; i < array.length - 1; i++) {
            for(int j = 0; j < array.length - i - 1; j++) {
                //Descending Order
                /*
                if(array[j] < array[j+1])
                 */

                //Ascending Order
                if(array[j] > array[j+1]) {
                    int temp = array[j];
                    array[j] = array[j+1];
                    array[j+1] = temp;
                }
            }
        }
    }

    /**
     * Selection sort method for sorting by the bubble sort algorithm.
     *
     * @param array : calls on the array elements in the driver class and sorts them using the Selection sort algorithm style.
     */
    protected static void selectionSort(int[] array) {// Selection sorting method.

        for(int i = 0; i < array.length - 1; i++) {
            int min = i;
            for(int j = i + 1; j < array.length; j++) {
                //Descending Order
                /*
                if(array[min] < array[j])
                 */



                //Ascending Order
                if(array[min] > array[j]) {
                    min = j;
                }
            }

            int temp = array[i];
            array[i] = array[min];
            array[min] = temp;
        }

    }




   /**
    * Insertion sort method for sorting by the insertion sort algorithm.
    *
    * @param array : calls on the array elements in the driver class and sorts them using the insertion sort algorithm style.
    */
   protected static void insertionSort(int[] array) {// insertion sorting method.

        for(int i = 1; i < array.length; i++) {
            int temp = array[i];// temp box for element
            int j = i - 1;

            while(j >= 0 && array[j] > temp) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = temp;
        }
    }



    /**
     * Merge sort method for sorting by the merge sort algorithm.
     *
     * @param array : calls on the array elements in the driver class and sorts them using the merge sort algorithm style.
     */
    protected static void mergeSort(int[] array) {// merge sort method

        int length = array.length;
        if (length <= 1) return; //base case

        int middle = length / 2;
        int[] leftArray = new int[middle];
        int[] rightArray = new int[length - middle];

        int i = 0; //left array
        int j = 0; //right array

        for(; i < length; i++) {
            if(i < middle) {
                leftArray[i] = array[i];
            }
            else {
                rightArray[j] = array[i];
                j++;
            }
        }
        mergeSort(leftArray);// calls the left array from merge method.
        mergeSort(rightArray);// calls the right array from the merg method.
        merge(leftArray, rightArray, array);
    }

    /**
     * Merge is sub method called on by the merge sort method to help find the and sort the left and right sides of the array.
     *
     * @param leftArray the left array holds half of the elements to be sorted.
     * @param rightArray the right array holds  the other half of the elements to be sorted.
     * @param array: calls on the array in the driver class to pull the elements to be sorted and merged from the two half of the array search style.
     */
    protected static void merge(int[] leftArray, int[] rightArray, int[] array) {// sub method to help from the left and right sides of the array.

        int leftSize = array.length / 2;
        int rightSize = array.length - leftSize;
        int i = 0, l = 0, r = 0; //indices

        //check the conditions for merging
        while(l < leftSize && r < rightSize) {
            if(leftArray[l] < rightArray[r]) {
                array[i] = leftArray[l];
                i++;
                l++;
            }
            else {
                array[i] = rightArray[r];
                i++;
                r++;
            }
        }
        while(l < leftSize) {
            array[i] = leftArray[l];
            i++;
            l++;
        }
        while(r < rightSize) {
            array[i] = rightArray[r];
            i++;
            r++;
        }
    }





    /**
     * Quick sort method for sorting by the quick sort algorithm.
     *
     * @param array: calls the array elements in the driver class.
     * @param start :holds the starting element from the array,used in partition method for sorting.
     * @param finish: holds the finishing element from the array,used in the partition method for sorting.
     */
    protected static void quickSort(int[] array, int start, int finish) {// quick sort method which uses a pivot point for sorting largews to smallest.

        if(finish < start) return; //base case

        int pivot = partition(array, start, finish);// calls on the partition sub method for the pivot point.
        quickSort(array, start, pivot - 1);
        quickSort(array, pivot + 1, finish);
    }

    
    /**
     * Partition, is a sub method called by the quicksort to find the start and finish and pivot elements in the array.
     *
     * @param array: instance of the array called on by the driver class.
     * @param start: the first element in the unsorted array list called by the driver class.
     * @param finish and array used by the pivot element to find the finish of the array of elements.
     * @return  returns the  partition values to the quicksort method to output to the main method  for user viewing.
     */
    protected static int partition(int[] array, int start, int finish) {// sub method for the quick sort method , helps find the pivot points well sorting int the arrays sides.

        int pivot = array[finish];
        int i = (start - 1);

        for(int j = start; j <= finish; j++) {
            if(array[j] < pivot) {
                i++;
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
        i++;
        int temp = array[i];
        array[i] = array[finish];
        array[finish] = temp;

        return i;
    }


}//END
