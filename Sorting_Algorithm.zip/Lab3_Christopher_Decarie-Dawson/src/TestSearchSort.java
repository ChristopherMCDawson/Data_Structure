import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;



/**
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * CET - CS Academic Level 3
 * This class will be the calling class to drive the program forward.
 * Student Name: Christopher Decarie-Dawson
 * Student Number:040718315
 * Section #: 301  
 * Course: CST8130 - Data Structures.
 *
 * @author/Student: Christopher Decarie-Dawson
 * @version 1.0
 */

public class TestSearchSort {//START

	





	

	/**
	 * The main method is the driver of the program and takes in input from the user to for menu options which call classes to run the program.
	 * While the program is active , the user can create and display an array of 30  numbers ranging from 10 to 100.
	 * the user can then search the array for a number using four methods of search , linear and binary  of iterative or recursive.
	 * both search types will also display the remaining elements of the array as well a time display in nano and milli seconds of operation time.
	 *
	 * @param args  a string array within the main method of the driver class
	 */
	public static void main(String[] args) {
		BinarylinearSearch bin = new BinarylinearSearch();
		Scanner scan  = new Scanner(System.in);// input scanner object for the system to take user input.
		int choice = 0;// holds the menu option choice.
		String thing = null ;// holds the sting value of the second switch statment.
		int[] test = new int [1000];// used to create a int array of 1000 elements.
		
		
		do {// do while loop to prompts user input for  printed menu.
			
			try {
				
				displayMainMenu();// displays the main menu.
				
				choice = Integer.parseInt(bin.emptyInput(scan));// holds the choice selected and throws an error is a mismatch is given.
				
				switch(choice) {// switch cases for each option with error messages for errors in input.
				case 1:
					 test = bin.generateRandomInts();// calls to initialize and pop. two arrays unsorted and sorted.
					 System.out.print("Unsorted array: "+Arrays.toString(test)+"\n");
				     Arrays.sort(test);// sorts the array into order.
				     System.out.print("Sorted array: "+Arrays.toString(test)+"\n");
					break;
				case 2:
					System.out.println("Please enter a number to be searched: ");// asks for the element to be found in the array and it's position using recursive search.
					int target = Integer.parseInt(bin.emptyInput(scan));// checks for the empty space error
					
					// Recursive Binary Search
					System.nanoTime();//notes time in nanoseconds
					System.currentTimeMillis();// notes time in milliseconds
					
					int result = bin.recursiveBinarySearch(test,0,test.length-1,target);// calls the method for the recursive binary search.
					System.out.println("Recursive Binary Search Result\n");					
					
					long endNanoTime = System.nanoTime();// closes the timer for nanoseconds.
					long endMilliTime = System.currentTimeMillis();// closes timer for milliseconds
					if(result ==-1) {
						System.out.println(target +" is not in the array.");
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime));// prints the end time stamp
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime));// prints the end time stamp
					}else {
						System.out.println(target +" is at index: "+ result);
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime));// prints the end time stamp
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime));// prints the end time stamp
					
					// Recursive linear Search
					System.nanoTime();//notes time in nanoseconds
					System.currentTimeMillis();// notes time in milliseconds
					
					bin.recursiveLinearSearch(test,0,test.length-1,target);// calls the method for the recursive linear search.
					
					System.out.println("recursive linear Search Resullt\n");
					
					long endNanoTime1 = System.nanoTime();// closes the timer for nanoseconds.
					long endMilliTime1 = System.currentTimeMillis();// closes timer for milliseconds
					if(result != -1) {
						System.out.println(target +" is not in the array.");
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime1));// prints the end time stamp
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime1));// prints the end time stamp
					}else {
						System.out.println(target +" is at index: " +result);
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime1));// prints the end time stamp
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime1));// prints the end time stamp	
					}
					}
					break;
				case 3:
					System.out.print("please enter a number to be searched: ");// asks for the element to be found in the array and it's position using iterative search.
					int search =Integer.parseInt(bin.emptyInput(scan));// checks for the empty space error
					
				
					//Iterative Binary Search
					System.nanoTime();//notes time in nanoseconds// closes the timer for nanoseconds.
					System.currentTimeMillis();// notes time in milliseconds
					
					
					int searched =bin.iterativerBinarySearch(test, search);// calls the method for the iterative binary search.
					
					System.out.println("Iterative Binary Search Result\n");
					long endNanoTimes = System.nanoTime();// closes the timer for nanoseconds.
					long endMilliTimes = System.currentTimeMillis();// closes timer for milliseconds
					if(searched ==-1) {
						System.out.println(searched+" is not in the array.");
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTimes));// prints the end time stamp
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTimes));// prints the end time stamp
					}else {
						System.out.println(searched+" is at index: "+search);
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTimes));// prints the end time stamp
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTimes));// prints the end time stamp
					}
					
					
					//Iterative linear Search
					System.nanoTime();//notes time in nanoseconds
					System.currentTimeMillis();// notes time in milliseconds
					
				
					int found =bin.iterativeLinearSearch(test, search);// calls the method for iterative linear search.
					System.out.println("Iterative Linear Search Result\n");
					
					long endNanoTime4 = System.nanoTime();// closes the timer for nanoseconds.
					long endMilliTime4 = System.currentTimeMillis();// closes timer for milliseconds
					if(found ==-1) {
						System.out.println(found+" is not in the array.");
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime4));// prints the end time stamp
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime4));// prints the end time stamp
					}else {
						System.out.println(found+" is at index: "+search);
						System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime4));// prints the end time stamp
						System.out.println("Operation time taken in milliseconds: "+ (endMilliTime4));// prints the end time stamp
					}
					break;
				case 4:	
					do {// do while loop that run till "R" is entered.
						
						try {
							displaySortingMenu();// displays the sub-menu for users.
							
							thing = scan.nextLine();//Scanner for the String element.	
						
									
						switch(thing) {// switch case start.
						
						case"B":
							System.nanoTime();//notes time in nanoseconds
							System.currentTimeMillis();// notes time in milliseconds
							test = bin.generateRandomInts();// Generates an array of random 1000 ints.
							System.out.println();
							System.out.print("Unsorted array: "+Arrays.toString(test)+"\n");// prints out the unsorted Array of elements.
							System.out.println();
							System.out.print("Bubble Sort: Simple sorting algoritm - 0(n2) Complexity -\n");// prints out the sorting type.
							System.out.println();
							SortingAlgorithm.bubbleSort(test);// method that calls Bubble sort.
							System.out.println("Bubble sorted array: "+Arrays.toString(test));// prints out the bubble sorted array.
							System.out.println();
							long endNanoTime5 = System.nanoTime();// closes the timer for nanoseconds.
							long endMilliTime5 = System.currentTimeMillis();// closes timer for milliseconds
							System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime5));// prints the end time stamp
							System.out.println("Operation time taken in milliseconds: "+ (endMilliTime5));// prints the end time stamp
							
							break;
						case"I":
							System.nanoTime();//notes time in nanoseconds
							System.currentTimeMillis();// notes time in milliseconds
							test = bin.generateRandomInts();// Generates an array of random 1000 ints.
							System.out.println();
							System.out.print("Unsorted array: "+Arrays.toString(test)+"\n");// prints out the unsorted Array of elements.
							System.out.println();
							System.out.print("Insertion Sort: Simple sorting algoritm - 0(n2) Complexity -\n");// prints out the sorting type.
							System.out.println();
							SortingAlgorithm.insertionSort(test);// method that calls insertionSort.
							System.out.println("Insertion sorted array: "+Arrays.toString(test));// prints out the Insertion sorted array.
							System.out.println();
							long endNanoTime6 = System.nanoTime();// closes the timer for nanoseconds.
							long endMilliTime6 = System.currentTimeMillis();// closes timer for milliseconds
							System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime6));// prints the end time stamp
							System.out.println("Operation time taken in milliseconds: "+ (endMilliTime6));// prints the end time stamp
							
							break;
						case"S":
							System.nanoTime();//notes time in nanoseconds
							System.currentTimeMillis();// notes time in milliseconds
							test = bin.generateRandomInts();// Generates an array of random 1000 ints.
							System.out.println();
							System.out.print("Unsorted array: "+Arrays.toString(test)+"\n");// prints out the unsorted Array of elements.
							System.out.println();
							System.out.print("Selection Sort: Simple sorting algoritm - 0(n2) Complexity -\n");// prints out the sorting type.
							System.out.println();
							SortingAlgorithm.selectionSort(test);// method that calls selectionSort.
							System.out.println("Selection sorted array: "+Arrays.toString(test));// prints out the Selecton sorted array.
							System.out.println();
							long endNanoTime7 = System.nanoTime();// closes the timer for nanoseconds.
							long endMilliTime7 = System.currentTimeMillis();// closes timer for milliseconds
							System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime7));// prints the end time stamp
							System.out.println("Operation time taken in milliseconds: "+ (endMilliTime7));// prints the end time stamp
							
							break;
						case"M":
							System.nanoTime();//notes time in nanoseconds
							System.currentTimeMillis();// notes time in milliseconds
							test = bin.generateRandomInts();// Generates an array of random 1000 ints.
							System.out.println();
							System.out.print("Unsorted array: "+Arrays.toString(test)+"\n");// prints out the unsorted Array of elements.
							System.out.println();
							System.out.print("Merge Sort: Recursive Divide-And-Conquer - 0(n log n) Complexity -\n");// prints out the sorting type.
							System.out.println();
							SortingAlgorithm.mergeSort(test);// calls on the mergeSort method.
							System.out.println("Merge sorted array: "+Arrays.toString(test));// prints the merge sorted array.
							System.out.println();
							long endNanoTime8 = System.nanoTime();// closes the timer for nanoseconds.
							long endMilliTime8 = System.currentTimeMillis();// closes timer for milliseconds
							System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime8));// prints the end time stamp
							System.out.println("Operation time taken in milliseconds: "+ (endMilliTime8));// prints the end time stamp
						
							break;
						case"Q":
							
							System.nanoTime();//notes time in nanoseconds
							System.currentTimeMillis();// notes time in milliseconds
							test = bin.generateRandomInts();// Generates an array of random 1000 ints.
							System.out.println();
							System.out.print("Unsorted array: "+Arrays.toString(test)+"\n");
							System.out.println();
							System.out.print("Quick Sort: Recursive Divide-And-Conquer - 0(n log n) Complexity -\n");// prints out the sorting type.
							System.out.println();							
							SortingAlgorithm.quickSort(test,0,test.length-1);// calls on the quickSort method.
							System.out.println("Quick sorted array: "+Arrays.toString(test));// prints the quick sortyed array.
							System.out.println();
							long endNanoTime9 = System.nanoTime();// closes the timer for nanoseconds.
							long endMilliTime9 = System.currentTimeMillis();// closes timer for milliseconds
							System.out.println("Operation time taken in nanoseconds: "+ (endNanoTime9));// prints the end time stamp
							System.out.println("Operation time taken in milliseconds: "+ (endMilliTime9));// prints the end time stamp
						
							break;
						case"R":
							
							//displayMainMenu();// displays the main menu.
							//scan.nextLine();
							//choice = Integer.parseInt(bin.emptyInput(scan));
							break;
						default:
								System.err.println("Invalid enter.. select options I-R");
								scan.nextLine();
						
					
					break;	
						}
						}catch(InputMismatchException | NumberFormatException e) {
							System.err.println("Invalid entry...selection options 1-5... please try again!");// mismatch catch for input errors.
							scan.nextLine();
						}
						}while(thing.equalsIgnoreCase("R"));// close loop
						
				case 5:
					System.out.println("Goodbye.... have a nice day");// Goodbye message for closing the program.
					break;
				default:
					System.err.println("Invalid entry...selection options 1-5... please try again!");// Error message for inproper input.
				}
			}
					
			catch(InputMismatchException | NumberFormatException | IllegalAccessException e) {
					System.err.println("Invalid entry...selection options 1-5... please try again!");// mismatch catch for input errors.
					scan.nextLine();
			}
			}while(choice != 5);
			// loops the program menu till 5 is input.


		
		scan.close();// Closes Scanner input	
		
}
	



	/**
	 * Displays main menu in the Console for user input.
	 */
	public static void  displayMainMenu() {// displays the menu format between selections.
		System.out.print("\nSelect your option in the menu:\n"+
				"1. Initialize and populate an array of 1000 random integers.\n"+
				"2. Performs recursive binary and linear search.\n"+
				"3. Perform iterative binary and linear search\n"+
				"4. Sort the array\n"+
				"5. To Exit\n");
		System.out.print("> ");
	}
	/**
	 * Displays the sub menu in the console for user to input into the array element sorting system.
	 */
	
	public static void displaySortingMenu() {// displays the sub menu format between selections.
		System.out.print("\n Select your option in the menu:\n"+
	"B.Bubble Sort\n"+
	"I.Insertion Sort\n"+
	"S.Selection Sort\n"+
	"M.Merge Sort\n"+
	"Q.Quick Sort\n"+
	"R.return to main menu");
	System.out.println("> ");
	}
	
	}//END


